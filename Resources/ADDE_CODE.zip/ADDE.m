for func_num=1:30
    for bt=1:30
        bound=100*2;
        D=30;
        Nmax=10*D;
        Nmin=2*D;
        N=Nmax;
        laststate=0;
        [X]=multini(N,D);
        cc=0.1;
        uCR=0.5*ones(2,1);
        uF=0.5*ones(2,1);
        A=[];
        PA=[X;A];
        arrate=2.5;
        arsize=N*arrate;
        FEs=0;
        FEscopy=0;
        FEmax=300000;
        NG=0.4*D;
        CG=30;
        update=0;
        perall=0;
        tt=0;
        draw=[];
        useCR=[];
        archive=[];
        archivevalue=[];
        Avalue=[];
        g=1;
        gt=1;
        
        XX=X';
        value=cec14_func(XX,func_num);
        PAvalue=[value,Avalue];
        FEs=FEs+N;
        FEssave=FEs;
        FEscopy=FEscopy+N;
        best=min(value);
        bestold=best;
        GB=find(value==best);
        gbest=X(GB(1),:);
        
        while(FEs<FEmax)
            
            [fsort,findex]=sort(value);
            SF=zeros(2,1);
            SCR=zeros(2,1);
            deltaf=zeros(2,1);
            [mA,nA]=size(A);
            suc=0;
            probad=0.5-0.005*10.^(2*FEs/FEmax);
            halfbestbest=findex(1:ceil(0.2*N));
            halfbest=findex(1:ceil((1-probad)*N));
            halfworst=findex(ceil((1-probad)*N)+1:N);
            lenbest=N-length(halfworst);
            
            sumd=sum(abs(X(findex(1),:)-X(findex(ceil(N/2)),:)));
            
            fac=sumd/bound/D;
            
            %�����׶ι���
            if((fac>=0)&&(fac<0.3))
                state=2;
            end
            if(fac>0.4)
                state=1;
            end
            
            
            if((fac>=0.3)&&(fac<=0.4))
                if(laststate==1)
                    state=1;
                else
                    state=2;
                end
            end
            
            
            if(g==1)
                state=1;
            end
            
            %��������������������Ӧ
%             for j=1:2
%                 F(j,:)=randCauchy(1,N,uF(j),0.1);
%                 CR(j,:)=normrnd(uCR(j),0.1,1,N);
%                 F(j,find(F(j,:)>1))=1;
%                 F(j,find(F(j,:)<0))=1E-10;
%                 CR(j,find(CR(j,:)>1))=1;
%                 CR(j,find(CR(j,:)<0))=1E-10;
%             end

            for j=1:2
                for i=1:N
                    F(j,i)= randCauchy(1,1,uF(j),0.1);
                    while(F(j,i)<=0)
                        F(j,i)= randCauchy(1,1,uF(j),0.1);
                    end
                    if(F(j,i)>=1)
                        F(j,i)=1;
                    end
                end
            end
            
            for j=1:2
                for i=1:N
                    CR(j,i)=normrnd(uCR(j),0.1,1,1);
                    
                    if(CR(j,i)>1)
                        CR(j,i)=1;
                    elseif(CR(j,i)<0)
                        CR(j,i)=1E-10;
                    end
                end
            end

            
            for i=1:N
                a=randperm(N);
                a(find(a==i))=[];
                pbrate=0.1;
                top=round(N*pbrate);
                indexnew=findex(1:top);
                c=randi(N+mA);
                while((c==i)||(c==a(1)))
                    c=randi(N+mA);
                end
                d=randi(top);
                
                %̽������ DE/current-to-rand/1
                if((~isempty(find(i==halfworst))))
                    if(value(a(2))<value(a(3)))
                        V(i,:)=X(i,:)+rand*(X(a(1),:)-X(i,:))+F(1,i)*(X(a(2),:)-X(a(3),:));
                    else
                        V(i,:)=X(i,:)+rand*(X(a(1),:)-X(i,:))+F(1,i)*(X(a(3),:)-X(a(2),:));
                    end
                    V(i,find(V(i,:)>100))=100;%(100+X(i,find(V(i,:)>100)))/2;
                    V(i,find(V(i,:)<-100))=-100;%(-100+X(i,find(V(i,:)<-100)))/2;
                    u(i,:)=V(i,:);
                
                 %�������� DE/current-to-pbest/1
                elseif(~isempty(find(i==halfbestbest)))
                    if(value(a(1))<PAvalue(c))
                        V(i,:)=X(i,:)+F(2,i)*(X(indexnew(d),:)-X(i,:))+F(2,i)*(X(a(1),:)-PA(c,:));
                    else
                        V(i,:)=X(i,:)+F(2,i)*(X(indexnew(d),:)-X(i,:))+F(2,i)*(PA(c,:)-X(a(1),:));
                    end
                    V(i,find(V(i,:)>100))=100;%(100+X(i,find(V(i,:)>100)))/2;
                    V(i,find(V(i,:)<-100))=-100;%(-100+X(i,find(V(i,:)<-100)))/2;
                    j_rand = floor(rand * D) + 1;
                    t = rand(1, D) < CR(2,i);
                    t(1, j_rand) = 1;
                    t_ = 1 - t;
                    u(i,:) = t .* V(i,:) + t_ .* X(i,:);
                else
                    %ƽ����� ̽��״̬ DE/current-to-rand/1
                    if(state==1)
                        if(value(a(2))<value(a(3)))
                            V(i,:)=X(i,:)+rand*(X(a(1),:)-X(i,:))+F(1,i)*(X(a(2),:)-X(a(3),:));
                        else
                            V(i,:)=X(i,:)+rand*(X(a(1),:)-X(i,:))+F(1,i)*(X(a(3),:)-X(a(2),:));
                        end
                        V(i,find(V(i,:)>100))=100;%(100+X(i,find(V(i,:)>100)))/2;
                        V(i,find(V(i,:)<-100))=-100;%(-100+X(i,find(V(i,:)<-100)))/2;
                        u(i,:)=V(i,:);
                        
                     %ƽ����� ����״̬ DE/current-to-pbest/1   
                    elseif(state==2)
                        if(value(a(1))<PAvalue(c))
                            V(i,:)=X(i,:)+F(2,i)*(X(indexnew(d),:)-X(i,:))+F(2,i)*(X(a(1),:)-PA(c,:));
                        else
                            V(i,:)=X(i,:)+F(2,i)*(X(indexnew(d),:)-X(i,:))+F(2,i)*(PA(c,:)-X(a(1),:));
                        end
                        V(i,find(V(i,:)>100))=100;%(100+X(i,find(V(i,:)>100)))/2;  ���ֱ߽紦����ʽ
                        V(i,find(V(i,:)<-100))=-100;%(-100+X(i,find(V(i,:)<-100)))/2;
                        j_rand = floor(rand * D) + 1;
                        t = rand(1, D) < CR(2,i);
                        t(1, j_rand) = 1;
                        t_ = 1 - t;
                        u(i,:) = t .* V(i,:) + t_ .* X(i,:);
                    end
                end
            end
            
            UU=u';
            aftervalue=cec14_func(UU,func_num);
            
            %�����ֲ�������Ӧ
            for i=1:N
                if(aftervalue(i)<value(i))
                    suc=suc+1;
                    if((~isempty(find(i==halfworst))))
                        deltaf(1,suc)=abs(value(i)-aftervalue(i))/value(i);
                        SF(1,suc)=F(1,i);
                        SCR(1,suc)=CR(1,i);
                    elseif(~isempty(find(i==halfbestbest)))
                        deltaf(2,suc)=abs(value(i)-aftervalue(i))/value(i);
                        SF(2,suc)=F(2,i);
                        SCR(2,suc)=CR(2,i);
                    else
                        deltaf(state,suc)=abs(value(i)-aftervalue(i))/value(i);
                        SF(state,suc)=F(state,i);
                        SCR(state,suc)=CR(state,i);
                    end
                    
                    A=[A;X(i,:)];
                    Avalue=[Avalue,value(i)];
                    value(i)=aftervalue(i);
                    X(i,:)=u(i,:);
                end
            end
            
            FEs=FEs+N;
            FEscopy=FEscopy+N;
            if(FEscopy>10000)
                FEscopy=FEscopy-10000;
                draw=[draw best-func_num*100];
            end
            
            for j=1:2
                if(~isempty(nonzeros(SCR(j,:))))
                    deltaf(j,:)=deltaf(j,:)/sum(deltaf(j,:));
                    uCR(j)=(1-cc)*uCR(j)+cc*sum(deltaf(j,:).*SCR(j,:));
                    uF(j)=(1-cc)*uF(j)+cc*sum(deltaf(j,:).*SF(j,:).^2)/sum(deltaf(j,:).*SF(j,:));
                end
            end
            
            FEssave=[FEssave FEs];
            useCR=[useCR uCR(2)];
            
            perE=10^(-1-4*FEs/FEmax);
            
            
            %����Ӧ��Ⱥ��ģ
            if(((mod(g,CG)==0)))
                best=min(value);
                per=(bestold-best)/bestold;
                %��С��Ⱥ��ģ
                if(best<bestold)&&(per>=perE)
                    Nnew=N-NG;
                    if(Nnew>=Nmin)
                        [valuesort,valueindex]=sort(value,'descend');
                        archive=[archive;X(valueindex(1:NG),:)];
                        archivevalue=[archivevalue value(valueindex(1:NG))];
                        X(valueindex(1:NG),:)=[];
                        value(valueindex(1:NG))=[];
                        N=Nnew;
                        aftervalue=[];
                        d=[];
                        dis=[];
                        fsort=[];
                        CR=[];
                        F=[];
                        u=[];
                        p=[];
                        V=[];
                    end
                else
                    %������Ⱥ��ģ
                    Nnew=N+NG;
                    if(Nnew<=Nmax)
                        [arm,arn]=size(archive);
                        mperm=randperm(arm);
                        new=archive(mperm(1:NG),:);
                        archive(mperm(1:NG),:)=[];
                        N=Nnew;
                        X=[X;new];
                        value=[value archivevalue(mperm(1:NG))];
                        aftervalue=[];
                        d=[];
                        dis=[];
                        fsort=[];
                        CR=[];
                        F=[];
                        u=[];
                        p=[];
                        V=[];
                    end
                end
                bestold=best;
            end
            
            arsize=round(N*arrate);
            [mA,nA]=size(A);
            Aperm=randperm(mA);
            if(mA>arsize)
                A((Aperm(1:(mA-arsize))),:)=[];
                Avalue(Aperm(1:(mA-arsize)))=[];
            end
            
            PA=[X;A];
            PAvalue=[value,Avalue];
            
            g=g+1;
            
        end
        func_num
        best-func_num*100
        best111(func_num,bt)=best-func_num*100;
        save ADDE best111;
        X=[];
        value=[];
        aftervalue=[];
        ffindex=[];
        d=[];
        dsort=[];
        fsort=[];
        ddindex=[];
        CR=[];
        F=[];
        u=[];
        V=[];
        sumstate=[];
    end  
end

