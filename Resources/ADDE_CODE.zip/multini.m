function [X]=multini(N,D)
X=200*rand(N,D)-100;


