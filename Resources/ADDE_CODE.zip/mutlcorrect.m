function X=mutlcorrect(X)
X(find(X>100))=200*rand-100;
X(find(X<-100))=200*rand-100;
