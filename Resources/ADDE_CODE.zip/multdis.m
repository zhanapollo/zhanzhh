function d=multdis(X,Y)
D=length(X);
dsum=sum((X-Y).^2);
d=sqrt(dsum);
