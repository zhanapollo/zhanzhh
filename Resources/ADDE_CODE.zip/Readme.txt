Thanks for your interest.

Moreover, the codes are for our ADDE algorithm, which is published as:
Z. H. Zhan, Z. J. Wang, H. Jin, and J. Zhang, “Adaptive distributed differential evolution,” IEEE Transactions on Cybernetics, vol. 50, no. 11, pp. 4633-4647, Nov. 2020.
https://ieeexplore.ieee.org/document/8878004

With these codes, we've two requests: 

1. If other researchers are interested in these codes, please direct them to us. We'd like to keep a record of researchers interested in these codes. 

2. If you happen to publish making use of these codes, please include some of our relevant publications in your list of references and, if space permits, please include an acknowledgement stating the usage of our codes. 

